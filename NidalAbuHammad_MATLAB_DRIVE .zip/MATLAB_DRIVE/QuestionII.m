%Question II
% Signal: 𝑦1(𝑡)= 𝑠𝑖𝑛 (0.2𝜋𝑡), 𝑦2(𝑡)= 𝑐𝑜𝑠 (0.4𝜋𝑡), 𝑦3(𝑡)= 𝑠𝑖𝑛 (0.8𝜋𝑡)
t = 0:0.0001:50;

y1 = sin(0.2*pi*t);
y2 = cos(0.4*pi*t);
y3 = sin(0.8*pi*t);

subplot(7,1,1);
plot(t,y1,'r','LineWidth',1.5);
title('𝑦1(𝑡)= 𝑠𝑖𝑛 (0.2𝜋𝑡)');
xlabel('Time(sec)');
ylabel('y1(t)');

subplot(7,1,2);
plot(t,y2,'b','LineWidth',1.5);
title('𝑦2(𝑡)= 𝑐𝑜𝑠 (0.4𝜋𝑡)');
xlabel('Time(sec)');
ylabel('y2(t)');

subplot(7,1,3);
plot(t,y3,'g','LineWidth',1.5);
title('𝑦3(𝑡)= 𝑠𝑖𝑛 (0.8𝜋𝑡)');
xlabel('Time(sec)');
ylabel('y3(t)');

% Signal: 𝑚1(𝑡)= 𝑦1+𝑦2 , 𝑚2(𝑡)= 𝑦1−𝑦2, and 𝑚3(𝑡)= 𝑦2×𝑦3, and 𝑚4(𝑡)= 𝑦1×𝑦3
m1 = y1+y2; m2 = y1-y2; m3 = y2.*y3; m4 = y1.*y3;
subplot(7,1,4);
plot(t,m1,'r','LineWidth',1.5);
title('𝑚1(𝑡)= 𝑦1+𝑦2');
xlabel('Time(sec)');
ylabel('m1(t)');

subplot(7,1,5);
plot(t,m2,'b','LineWidth',1.5);
title('𝑚2(𝑡)= 𝑦1−𝑦2');
xlabel('Time(sec)');
ylabel('m2(t)');

subplot(7,1,6);
plot(t,m3,'g','LineWidth',1.5);
title('𝑚3(𝑡)= 𝑦2×𝑦3');
xlabel('Time(sec)');
ylabel('m3(t)');

subplot(7,1,7);
plot(t,m4,'y','LineWidth',1.5);
title('𝑚4(𝑡)= 𝑦1×𝑦3');
xlabel('Time(sec)');
ylabel('m4(t)');

%m1(t) Amplitude spectral representation
Y = fft(m1);

Fs = 1/(t(2)-t(1)); %Sampling Frequency
f = (-Fs/2 : Fs/length(m1):Fs/2 - Fs/length(m1)); %Defining frequency of the plot
subplot(2,1,1);
plot(f,abs(fftshift(Y)),'r','LineWidth',1.5);
title('Spectral representation of m1(t)');
xlabel('Frequency (Hz)');
ylabel('Magnitude');





%m2(t) Amplitude spectral representation
%m3(t) Amplitude spectral representation
%m4(t) Amplitude spectral representation
