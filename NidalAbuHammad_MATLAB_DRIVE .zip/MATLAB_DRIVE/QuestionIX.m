syms s t

% Transfer function
H1(s) = 10000*(s+3)/(s^2 + 6*s + 8);
H2(s) = 100*(s-3)/(s^2 + 2*s + 1);
Y1s = H1(s)/s;      % Step response
Y2s = H2(s)/s;
y1s(t) = ilaplace(Y1s);
y2s(t) = ilaplace(Y2s);

Y(t) = y1s(t) + y2s(t);

fplot(Y, [0 5], 'LineWidth', 1.5)
grid on
title('Step Response')
xlabel('Time (sec)')
ylabel('ys(t)')
