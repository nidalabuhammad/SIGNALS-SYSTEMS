% Signal: 𝑦1(𝑡)= 𝑠𝑖𝑛 (0.2𝜋𝑡), 𝑦2(𝑡)= 𝑐𝑜𝑠 (0.4𝜋𝑡), 𝑦3(𝑡)= 𝑠𝑖𝑛 (0.8𝜋𝑡)
t = 0:0.0001:50;

y1 = sin(0.2*pi*t);
y2 = cos(0.4*pi*t);
y3 = sin(0.8*pi*t);

% Signal: 𝑚1(𝑡)= 𝑦1+𝑦2 , 𝑚2(𝑡)= 𝑦1−𝑦2, and 𝑚3(𝑡)= 𝑦2×𝑦3, and 𝑚4(𝑡)= 𝑦1×𝑦3
m1 = y1+y2; m2 = y1-y2; m3 = y2.*y3; m4 = y1.*y3;


%m1(t) Amplitude spectral representation
Y = fft(m1);

Fs = 1/(t(2)-t(1)); %Sampling Frequency
f = (-Fs/2 : Fs/length(m1):Fs/2 - Fs/length(m1)); %Defining frequency of the plot
subplot(4,1,1);
plot(f,abs(fftshift(Y)),'r','LineWidth',1.5);
title('Spectral representation of m1(t)');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
%m2(t) Amplitude spectral representation
Y = fft(m2);

Fs = 1/(t(2)-t(1)); %Sampling Frequency
f = (-Fs/2 : Fs/length(m2):Fs/2 - Fs/length(m2)); %Defining frequency of the plot
subplot(4,1,2);
plot(f,abs(fftshift(Y)),'b','LineWidth',1.5);
title('Spectral representation of m2(t)');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
%m3(t) Amplitude spectral representation
Y = fft(m3);

Fs = 1/(t(2)-t(1)); %Sampling Frequency
f = (-Fs/2 : Fs/length(m3):Fs/2 - Fs/length(m3)); %Defining frequency of the plot
subplot(4,1,3);
plot(f,abs(fftshift(Y)),'g','LineWidth',1.5);
title('Spectral representation of m3(t)');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
%m4(t) Amplitude spectral representation
Y = fft(m4);

Fs = 1/(t(2)-t(1)); %Sampling Frequency
f = (-Fs/2 : Fs/length(m4):Fs/2 - Fs/length(m4)); %Defining frequency of the plot
subplot(4,1,4);
plot(f,abs(fftshift(Y)),'y','LineWidth',1.5);
title('Spectral representation of m4(t)');
xlabel('Frequency (Hz)');
ylabel('Magnitude');