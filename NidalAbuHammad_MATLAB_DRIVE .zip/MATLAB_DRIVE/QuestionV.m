syms t tau
%𝑦1(𝑡)=(10𝑒^−2𝑡)𝜋((𝑡−5)/4) and 𝑦2(𝑡)=𝜋((𝑡−1)/2)
y1 = 10*exp(- 2*tau).*rectangularPulse((tau-5)/4);
y2 = rectangularPulse((t-tau-1)/2);

Y = int(y1.*y2,tau,-inf,inf);

fplot(Y, [0 50], 'LineWidth', 1.5)
grid on
xlabel('Time(sec)')
ylabel('y1 * y2')
title('y1 and y2 Convolution')

%𝑦3(𝑡)=(10𝑒^2𝑡)𝜋((𝑡−5)/4) and 𝑦4(𝑡) =𝜋((𝑡−1)/2)
y3 = 10*exp(2*tau).*rectangularPulse((tau-5)/4);
y4 = rectangularPulse((t-tau-1)/2);

Y2 = int(y1.*y2,tau,-inf,inf);

fplot(Y, [0 50], 'LineWidth', 1.5)
grid on
xlabel('Time(sec)')
ylabel('y3 * y4')
title('y3 and y4 Convolution')