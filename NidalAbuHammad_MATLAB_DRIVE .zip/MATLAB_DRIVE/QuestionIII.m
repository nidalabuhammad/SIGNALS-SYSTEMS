%Question III
% dy(t)dt+0.25y(t)=10𝑢(𝑡)// zero-state responses
syms t y(t)

u = heaviside(t);
E = diff(y,t) + 0.25*y(t) == 10*u;
cond = y(0) == 0; %Zero-State Response

y(t)= dsolve(E,cond)

% d2y(t)dt2+4dydt +5y(t)=5 cos (0.01πt) // zero-state responses
syms t y(t)
dy = diff(y,t) ;
E = diff(y,2) + 4*dy + 5*y(t) == 5*cos(0.01*pi*t);
cond1 = y(0) == 0;
cond2 = dy(0) == 0;

y(t) = dsolve(E,cond1,cond2)

% d2y(t)dt2+4dydt +5y(t)=5u(t) // zero-state responses
syms t y(t)
dy = diff(y,t) ;
E = diff(y,2) + 4*dy + 5*y(t) == 5*u;
cond1 = y(0) == 0;
cond2 = dy(0) == 0;

y(t) = dsolve(E,cond1,cond2)