%Question VI Laplace Transform
%𝑦(𝑡)=(10−10𝑒^−0.125𝑡)u(t)
syms t s

y = (10 - 10*exp(-0.125*t)).*heaviside(t);
Y  = laplace(y);
pretty(Y)       %Displays the transform in formated form 

%𝑦(𝑡)=(16+4𝑒^−2𝑡*𝑐𝑜𝑠(0.2𝜋𝑡))u(t)
syms t s

y = (16 + 4*exp(-2*t).*cos(0.2*pi*t)).*heaviside(t);
Y  = laplace(y);
pretty(Y)       %Displays the transform in formated form  
