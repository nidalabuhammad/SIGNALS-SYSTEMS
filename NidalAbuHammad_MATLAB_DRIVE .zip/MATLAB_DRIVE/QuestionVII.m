% Determining the pole-zero map
num = [10 5];
den = [6 0 -7 0 2 9];

G = tf(num, den)
figure
pzmap(G)
grid on
title('Pole-Zero Map')
poles = pole(G)
zeros = zero(G)