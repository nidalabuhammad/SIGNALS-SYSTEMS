% Determining the pole-zero map
%𝐻(𝑠)=10000(s+3/𝑠^2+6𝑠+8)
num = [1 3];
den = [1 6 8];

G = tf(10000*num, den)
figure
pzmap(G)
grid on
title('Pole-Zero Map')
poles = pole(G)
zeros = zero(G)