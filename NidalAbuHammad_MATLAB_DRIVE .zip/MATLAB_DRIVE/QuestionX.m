%spectral representation of the message, the carrier, and the modulated signal
% Basic signal setup
amp_msg = 10;          % Message signal amplitude
freq_msg = 100;        % Message signal frequency (Hz)
amp_carrier = 15;      % Carrier signal amplitude
freq_carrier = 1200;   % Carrier signal frequency (Hz)
Fs = 10000;            % Sampling frequency (Hz)
t = 0:1/Fs:0.05;       % Time vector

% Generate signals
message = amp_msg * cos(2*pi*freq_msg*t);          % Message signal
carrier = amp_carrier * cos(2*pi*freq_carrier*t);  % Carrier signal
mod_signal = message .* carrier;                   % DSB-SC modulated signal

% Time domain plots
figure;

subplot(3,1,1);
plot(t, message);
title('Message Signal');
xlabel('Time (sec)');
ylabel('Amplitude');
grid on;

subplot(3,1,2);
plot(t, carrier);
title('Carrier Signal');
xlabel('Time (sec)');
ylabel('Amplitude');
grid on;

subplot(3,1,3);
plot(t, mod_signal);
title('DSB-SC Modulated Signal');
xlabel('Time (sec)');
ylabel('Amplitude');
grid on;


% Frequency domain analysis
N = length(t);
f_axis = (-N/2 : N/2-1) * (Fs/N);

MSG_F  = abs(fftshift(fft(message)));
CARR_F = abs(fftshift(fft(carrier)));
MOD_F  = abs(fftshift(fft(mod_signal)));

% Normalize for better comparison
MSG_F  = MSG_F  / max(MSG_F);
CARR_F = CARR_F / max(CARR_F);
MOD_F  = MOD_F  / max(MOD_F);

% Frequency domain plots
figure;

subplot(3,1,1);
plot(f_axis, MSG_F,'r','LineWidth',1);
title('Message Signal Spectrum');
xlabel('Frequency (Hz)');
ylabel('|M(f)|');
grid on;

subplot(3,1,2);
plot(f_axis, CARR_F,'b','LineWidth',1);
title('Carrier Signal Spectrum');
xlabel('Frequency (Hz)');
ylabel('|C(f)|');
grid on;

subplot(3,1,3);
plot(f_axis, MOD_F,'g','LineWidth',1);
title('Modulated Signal Spectrum');
xlabel('Frequency (Hz)');
ylabel('|S(f)|');
grid on;
