%Question I
%Siganl 1: 𝑥(𝑡) = 𝑢(𝑡−1)− 𝑟(𝑡−7)+𝑟(−𝑡+4)
t1 = -1:0.001:10;
u1  = (t1-1) >= 0;
u2  = (t1-7) >= 0;
u3  = (4-t1) >= 0;

r2 = (t1-7).*u2;
r3 = (4-t1).*u3;
x1 = u1 - r2 + r3;
%figure for Signal 1
plot(t1,x1,'b','LineWidth',1.5);
title('𝑥(𝑡) = 𝑢(𝑡−1)− 𝑟(𝑡−7)+𝑟(−𝑡+4)');
xlabel('Time(sec)');
ylabel('x(t)');
%Signal 2: A finite pulse (𝜋(𝑡6)) with value = 5 centered at t=10
t2 = -1:0.001:20;
x2 = 5*rectangularPulse(1/6*(t2-10))
%figure for Signal 2
plot(t2,x2,'b','LineWidth',1.5);
title('𝑥(𝑡) = 𝜋((t-10)/6)');
xlabel('Time(sec)');
ylabel('x(t)');

%Signal 3: 𝑥(𝑡)= 𝑝(𝑡)𝜋(𝑡−36)−𝑟(𝑡−7)+𝑟(𝑡−13)−𝑢(𝑡−13) in the time interval [0 22]
t3 = 0:0.001:50;
p = 0.5*(t3.^2).*(t3 >=0);
a = p.*rectangularPulse(t3-36);
u4 = (t3-13) >= 0; r4 = (t3-13).*u4;
u5 = (t3-7) >=0; r5 = (t3-7).*u5;
x3 = a - r5 + r4 - u4; 
%figure for Signal 3
plot(t3,x3,'b','LineWidth',1.5);
title('𝑥(𝑡)= 𝑝(𝑡)𝜋(𝑡−36)−𝑟(𝑡−7)+𝑟(𝑡−13)−𝑢(𝑡−13)');
xlabel('Time(sec)');
ylabel('x(t)');
