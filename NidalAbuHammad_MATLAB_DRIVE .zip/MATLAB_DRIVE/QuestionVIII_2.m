syms s t

% Transfer function
H(s) = 1000*(s+3)/(s^2 + 6*s + 8);
Ys = H(s)/s;      % Step response
ys(t) = ilaplace(Ys);
Yr = H(s)/s^2;    % Ramp response
yr(t) = ilaplace(Yr);

subplot(2,1,1)
fplot(ys, [0 5], 'LineWidth', 1.5)
grid on
title('Step Response')
xlabel('Time (sec)')
ylabel('ys(t)')

subplot(2,1,2)
fplot(yr, [0 5], 'LineWidth', 1.5)
grid on
title('Ramp Response')
xlabel('Time (sec)')
ylabel('yr(t)')
